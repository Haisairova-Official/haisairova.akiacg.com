import {
  commandType,
  IAsset,
  IScene,
  ISentence,
} from './interface/sceneInterface';
import { scriptParser } from './scriptParser/scriptParser';
import { fileType } from './interface/assets';
import { ConfigMap } from './config/scriptConfig';
import {
  isLineBreakPlaceholder,
  sceneTextPreProcess,
} from './sceneTextPreProcessor';

/**
 * 场景解析器
 * @param rawScene 原始场景
 * @param sceneName 场景名称
 * @param sceneUrl 场景url
 * @param assetsPrefetcher
 * @param assetSetter
 * @param ADD_NEXT_ARG_LIST
 * @param SCRIPT_CONFIG_MAP
 * @return {IScene} 解析后的场景
 */
export const sceneParser = (
  rawScene: string,
  sceneName: string,
  sceneUrl: string,
  assetsPrefetcher: ((assetList: Array<IAsset>) => void) | undefined,
  assetSetter: (fileName: string, assetType: fileType) => string,
  ADD_NEXT_ARG_LIST: commandType[],
  SCRIPT_CONFIG_MAP: ConfigMap,
): IScene => {
  // 没有预取回调时不需要场景级资源列表，连同每条语句的资源扫描一起跳过
  const collectAssets = assetsPrefetcher !== undefined;

  // 预处理把多行语句折叠进它的首行，并用占位行补齐被折叠掉的行，
  // 因此这里的行数与原始场景严格一致，「语句 index == 文件行号」始终成立。
  const rawSentenceList = sceneTextPreProcess(rawScene).split('\n'); // 原始句子列表

  // 去分号留到后面去做了，现在注释要单独处理
  const rawSentenceListWithoutEmpty = rawSentenceList;
  // .map((sentence) => sentence.split(";")[0])
  // .filter((sentence) => sentence.trim() !== "");
  let assetsList: Array<IAsset> = []; // 场景资源列表
  let subSceneList: Array<string> = []; // 子场景列表
  const sentenceList: Array<ISentence> = rawSentenceListWithoutEmpty.map(
    (sentence, index) => {
      const returnSentence: ISentence = scriptParser(
        sentence,
        assetSetter,
        ADD_NEXT_ARG_LIST,
        SCRIPT_CONFIG_MAP,
        index,
        collectAssets,
      );
      if (!collectAssets) {
        return returnSentence;
      }
      // 在这里解析出语句可能携带的资源和场景，合并到 assetsList 和 subSceneList。
      // 必须就地追加：如果写成 [...assetsList, ...sentenceAssets]，每条语句都要复制
      // 一次已累积的列表，整体退化成 Θ(资源数²)——资源密集的场景脚本（几乎每条语句
      // 都带 bg / figure / vocal）在数千条语句规模下会明显变慢。
      for (const asset of returnSentence.sentenceAssets) {
        assetsList.push(asset);
      }
      for (const subScene of returnSentence.subScene) {
        subSceneList.push(subScene);
      }
      return returnSentence;
    },
  );

  markMultilineRanges(sentenceList, rawSentenceList);

  if (collectAssets) {
    // 开始资源的预加载
    assetsList = deduplicateAssets(assetsList);
    assetsPrefetcher(assetsList);
  }

  return {
    sceneName: sceneName, // 场景名称
    sceneUrl: sceneUrl,
    sentenceList: sentenceList, // 语句列表
    assetsList: assetsList, // 资源列表
    subSceneList: subSceneList, // 子场景列表
  };
};

/**
 * 回填多行语句的行范围。
 *
 * 预处理后，一条多行语句的完整内容都落在它的首行，紧跟其后的若干占位行
 * 就是被折叠掉的续行。这里把占位行标记出来，并把首行语句的 endLine
 * 推到最后一条续行，图形编辑器据此按整个行范围替换语句。
 *
 * @param sentenceList 解析后的语句列表
 * @param processedLines 预处理后的行，与 sentenceList 一一对应
 */
const markMultilineRanges = (
  sentenceList: ISentence[],
  processedLines: string[],
) => {
  let headIndex = -1; // 最近一条非占位语句的下标，即当前多行语句的首行
  for (let index = 0; index < sentenceList.length; index++) {
    if (!isLineBreakPlaceholder(processedLines[index])) {
      headIndex = index;
      continue;
    }
    sentenceList[index].isLineBreakHolder = true;
    if (headIndex >= 0) {
      sentenceList[headIndex].endLine = index;
    }
  }
};

const deduplicateAssets = (assetsList: IAsset[]): IAsset[] => {
  const seenAssets = new Set<string>();
  return assetsList.filter((asset) => {
    if (!asset || typeof asset.url !== 'string' || asset.url === '') {
      return false;
    }
    const assetKey = `${asset.type}:${asset.url}`;
    if (seenAssets.has(assetKey)) {
      return false;
    }
    seenAssets.add(assetKey);
    return true;
  });
};
