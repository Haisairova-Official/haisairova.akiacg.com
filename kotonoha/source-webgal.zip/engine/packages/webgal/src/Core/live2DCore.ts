import { Texture } from 'pixi.js';
import { installLive2dAssetCache } from './controller/stage/pixi/assets/live2dAssetCache';
/** 眨眼参数，毫秒 */
export interface BlinkParam {
  blinkInterval: number; // 眨眼间隔
  blinkIntervalRandom: number; // 眨眼间隔随机范围
  closingDuration: number; // 闭眼
  closedDuration: number; // 保持闭眼
  openingDuration: number; // 睁眼
}

export const baseBlinkParam: BlinkParam = {
  blinkInterval: 24 * 60 * 60 * 1000, // 24小时
  blinkIntervalRandom: 1000,
  closingDuration: 100,
  closedDuration: 50,
  openingDuration: 150,
};

export interface FocusParam {
  x: number; // 焦点X位置
  y: number; // 焦点Y位置
  instant: boolean; // 是否瞬间切换焦点
}

export const baseFocusParam: FocusParam = {
  x: 0,
  y: 0,
  instant: false,
};

export class Live2DCore {
  public isAvailable = false;
  public readonly ready: Promise<void>;

  public Live2DModel: any;
  public SoundManager: any;
  public Config: any;

  public createCubism2Texture?: (texture: Texture) => Texture;
  public reserveCoreMemory?: (size: number) => void;

  // 临时记录未初始化前的数据
  // 旧版表情混合模式
  private _legacyExpressionBlendMode = false;
  public get legacyExpressionBlendMode() {
    return this._legacyExpressionBlendMode;
  }
  public set legacyExpressionBlendMode(value: boolean) {
    this._legacyExpressionBlendMode = value;
    if (this.isAvailable) {
      this.Config.legacyExpressionBlendMode = value;
    }
  }

  // CubismCore预留堆内存容量，单位MB；PLDW的对应API的单位是byte
  private _cubismMemoryReservedSize = 32
  public get CubismMemoryReservedSize() {
    return this._cubismMemoryReservedSize;
  }
  public set CubismMemoryReservedSize(size: number) {
    this._cubismMemoryReservedSize = size;
    if (this.isAvailable && this.reserveCoreMemory) {
      this.reserveCoreMemory(this.CubismMemoryReservedSize * 1024 * 1024);
    }
  }

  public constructor() {
    this.ready = this.initLive2D();
  }

  public initLive2D() {
    // @ts-expect-error live2dPromise is a global variable
    return (window.live2dPromise as Promise<[boolean, boolean]>)
      .then(async ([live2d2dAvailable, live2d4Available]) => {
        const _isAvailable = live2d2dAvailable && live2d4Available;
        if (!_isAvailable) {
          console.warn('live2d plugin load failed');
          return;
        }
        const {
          Live2DModel,
          SoundManager,
          config,
          Live2DLoader,
          ModelSettings,
          createCubism2Texture,
          reserveCoreMemory,
        } = await import('pixi-live2d-display-webgal');
        installLive2dAssetCache({ Live2DLoader, ModelSettings });
        this.Live2DModel = Live2DModel;
        this.SoundManager = SoundManager;
        this.Config = config;
        this.isAvailable = true;
        this.createCubism2Texture = createCubism2Texture;
        this.reserveCoreMemory = reserveCoreMemory;
        console.log('Live2D plugin load success');
        this.initConfig();
        if (this.reserveCoreMemory) {
          this.reserveCoreMemory(this.CubismMemoryReservedSize * 1024 * 1024);
        }
      })
      .catch((error) => {
        this.isAvailable = false;
        console.warn('Live2D plugin load failed', error);
      })
      .finally(() => {
        // @ts-expect-error live2dPromise is a global variable
        delete window.live2dPromise;
      });
  }

  /** 初始化配置 */
  private initConfig() {
    this.Config.legacyExpressionBlendMode = this._legacyExpressionBlendMode;
  }
}
