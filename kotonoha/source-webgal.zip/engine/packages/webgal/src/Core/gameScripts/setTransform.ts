import { ISentence } from '@/Core/controller/scene/sceneInterface';
import { IPerform } from '@/Core/Modules/perform/performInterface';
import {
  getBooleanArgByKey,
  getNumberArgByKey,
  getStringArgByKey,
  resolveTransformArgs,
} from '@/Core/util/getSentenceArg';
import { IAnimationObject } from '@/Core/controller/stage/pixi/PixiController';
import { logger } from '@/Core/util/logger';
import { AnimationFrame } from '../Modules/animations';
import { generateTransformAnimationObj } from '@/Core/controller/stage/pixi/animations/generateTransformAnimationObj';
import { WebGAL } from '@/Core/WebGAL';
import { applyAnimationEndState, getAnimateDuration } from '../Modules/animationFunctions';
import { v4 as uuid } from 'uuid';
import { generateTimelineObj } from '@/Core/controller/stage/pixi/animations/timeline';
import { parseSetTransformFrame } from './parseTransformFrame';
/**
 * 设置变换
 * @param sentence
 */
export const setTransform = (sentence: ISentence): IPerform => {
  const animationName = uuid();
  const animationString = sentence.content;
  let animationObj: AnimationFrame[];

  const duration = getNumberArgByKey(sentence, 'duration') ?? 500;
  const ease = getStringArgByKey(sentence, 'ease') ?? '';
  const target = getStringArgByKey(sentence, 'target') ?? '0';
  const keep = getBooleanArgByKey(sentence, 'keep') ?? false;
  const parallel = getBooleanArgByKey(sentence, 'parallel') ?? false;
  const { writeDefault, writeFullEffect } = resolveTransformArgs(sentence, parallel);

  const performInitName = `animation-${target}`;
  const performName = parallel ? `${performInitName}#${animationName}` : performInitName;

  if (!parallel) WebGAL.gameplay.performController.unmountPerform(performInitName, true);

  const frame = parseSetTransformFrame(animationString);
  if (frame) {
    animationObj = generateTransformAnimationObj(target, frame, duration, ease, writeFullEffect);
  } else {
    animationObj = [];
  }

  WebGAL.animationManager.addAnimation(animationName, animationObj);
  const animationDuration = getAnimateDuration(animationName);
  const animationTimeline = applyAnimationEndState(animationName, target, writeDefault, writeFullEffect);
  const key = `${target}-${animationName}-${animationDuration}`;
  let keepAnimationStopped = false;
  const startFunction = () => {
    if (keep && keepAnimationStopped) {
      return;
    }
    const animationObj: IAnimationObject | null = animationTimeline
      ? generateTimelineObj(animationTimeline, target, animationDuration)
      : null;
    if (animationObj) {
      logger.debug(`动画${animationName}作用在${target}`, animationDuration);
      WebGAL.gameplay.pixiStage?.registerAnimation(animationObj, key, target);
    }
  };
  const stopFunction = () => {
    if (keep) {
      WebGAL.gameplay.pixiStage?.removeAnimationWithoutSetEndState(key);
      keepAnimationStopped = true;
      return;
    }
    // 终态已在命令函数阶段写入 effects，这里只把容器推到终态，不回写演算状态
    WebGAL.gameplay.pixiStage?.removeAnimation(key);
  };

  return {
    performName: performName,
    duration: animationDuration,
    isHoldOn: keep,
    startFunction,
    stopFunction,
    blockingNext: () => false,
    blockingAuto: () => !keep,
  };
};
