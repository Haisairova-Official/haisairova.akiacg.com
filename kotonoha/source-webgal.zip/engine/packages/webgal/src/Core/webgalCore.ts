import { BacklogManager } from '@/Core/Modules/backlog';
import { ReadHistoryManager } from './Modules/readHistory';
import mitt from 'mitt';
import { SceneManager } from '@/Core/Modules/scene';
import { AnimationManager } from '@/Core/Modules/animations';
import { Gameplay } from './Modules/gamePlay';
import { Events } from '@/Core/Modules/events';
import { SteamIntegration } from '@/Core/integration/steamIntegration';
import { WebgalTemplate } from '@/types/template';
import { IWebGALStyleObj } from 'webgal-parser/build/types/styleParser';
import { stageStateManager } from '@/Core/Modules/stage/stageStateManager';
import { FlowchartManager } from '@/Core/Modules/flowchart';
import { FigureDiffManager } from '@/Core/controller/stage/pixi/figureDiff';

export class WebgalCore {
  public sceneManager = new SceneManager();
  public backlogManager = new BacklogManager(this.sceneManager);
  public flowchartManager = new FlowchartManager(this.sceneManager);
  public readHistoryManager = new ReadHistoryManager(this.sceneManager);
  public animationManager = new AnimationManager();
  public gameplay = new Gameplay();
  public gameName = '';
  public gameKey = '';
  public events = new Events();
  public stageManager = stageStateManager;
  public readonly figureDiffManager = new FigureDiffManager();
  public steam = new SteamIntegration();
  public template: WebgalTemplate | null = null;
  public styleObjects: Map<string, IWebGALStyleObj> = new Map();
}
