// 切换自动播放状态
import { stopAuto } from './autoPlay';
import styles from '@/UI/BottomControlPanel/bottomControlPanel.module.scss';
import { nextSentence } from '@/Core/controller/gamePlay/nextSentence';

import { WebGAL } from '@/Core/WebGAL';
import { webgalStore } from '@/store/store';
import { SYSTEM_CONFIG } from '@/config';
import { stageStateManager } from '@/Core/Modules/stage/stageStateManager';

let temporaryFastTimeout: ReturnType<typeof setTimeout> | null = null;

const clearTemporaryFast = () => {
  if (temporaryFastTimeout !== null) clearTimeout(temporaryFastTimeout);
  temporaryFastTimeout = null;
};

/**
 * 设置 fast 按钮的激活与否
 * @param on
 */
export const setFastButton = (on: boolean) => {
  const autoIcon = document.getElementById('Button_ControlPanel_fast');
  if (autoIcon) {
    if (on) {
      autoIcon.className = styles.button_on;
    } else autoIcon.className = styles.singleButton;
  }
};

/**
 * 停止快进模式
 */
export const stopFast = () => {
  clearTemporaryFast();
  WebGAL.gameplay.isFast = false;
  if (WebGAL.gameplay.fastInterval !== null) {
    clearInterval(WebGAL.gameplay.fastInterval);
    WebGAL.gameplay.fastInterval = null;
  }
};

/**
 * 开启快进
 */
export const startFast = (force = false) => {
  clearTemporaryFast();
  if (WebGAL.gameplay.fastInterval !== null) {
    return;
  }
  WebGAL.gameplay.isFast = true;
  const skipAll = force || webgalStore.getState().userData.optionData.skipAll;
  WebGAL.gameplay.fastInterval = setInterval(() => {
    if (!skipAll && !stageStateManager.getCalculationStageState().isRead) {
      stopFast();
      return;
    }
    nextSentence();
  }, SYSTEM_CONFIG.fast_timeout);
};

export const startTemporaryFast = (duration = 150) => {
  clearTemporaryFast();
  if (WebGAL.gameplay.fastInterval !== null) stopFast();
  WebGAL.gameplay.isFast = true;
  // 临时快进状态持续 duration 毫秒，供此期间的演出判断是否跳过动画。
  temporaryFastTimeout = setTimeout(() => {
    if (WebGAL.gameplay.fastInterval === null) {
      WebGAL.gameplay.isFast = false;
    }
    temporaryFastTimeout = null;
  }, duration);
};

// 判断是否是快进模式
export const isFast = function () {
  return WebGAL.gameplay.isFast;
};

/**
 * 停止快进模式与自动播放
 */
export const stopAll = () => {
  stopFast();
  stopAuto();
};

/**
 * 切换快进模式
 */
export const switchFast = () => {
  // 现在正在快进
  if (WebGAL.gameplay.fastInterval !== null) {
    stopFast();
  } else {
    // 当前不在快进
    startFast();
  }
};
