import page_flip_1 from '@/assets/se/tone.wav';
import switch_1 from '@/assets/se/tone.wav';
import mouse_enter from '@/assets/se/tone.wav';
import dialog_se from '@/assets/se/tone.wav';
import click_se from '@/assets/se/tone.wav';
import { stageStateManager } from '@/Core/Modules/stage/stageStateManager';

/**
 * 调用音效
 */
const useSoundEffect = () => {
  const playSeEnter = () => {
    stageStateManager.setStageAndCommit('uiSe', mouse_enter);
  };
  const playSeClick = () => {
    stageStateManager.setStageAndCommit('uiSe', click_se);
  };
  const playSeSwitch = () => {
    stageStateManager.setStageAndCommit('uiSe', switch_1);
  };
  const playSePageChange = () => {
    stageStateManager.setStageAndCommit('uiSe', page_flip_1);
  };

  const playSeDialogOpen = () => {
    stageStateManager.setStageAndCommit('uiSe', dialog_se);
  };

  return {
    playSeEnter,
    playSeClick,
    playSePageChange,
    playSeDialogOpen,
    playSeSwitch,
  };
};

/**
 * 调用音效（只供 choose.tsx 使用）
 */
export const useSEByWebgalStore = () => {
  const playSeEnter = () => {
    stageStateManager.setStageAndCommit('uiSe', mouse_enter);
  };
  const playSeClick = () => {
    stageStateManager.setStageAndCommit('uiSe', click_se);
  };
  return {
    playSeEnter, // 鼠标进入
    playSeClick, // 鼠标点击
  };
};

export default useSoundEffect;
