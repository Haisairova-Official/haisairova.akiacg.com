import { resolveVideoSource } from '@/Core/util/videoParts';
import { tryPlayMedia, queueMediaRecovery, cancelMediaRecovery } from '@/Core/util/mediaRecovery';
import { ISentence } from '@/Core/controller/scene/sceneInterface';
import { IPerform } from '@/Core/Modules/perform/performInterface';
import React from 'react';
import ReactDOM from 'react-dom';
import styles from '@/Stage/FullScreenPerform/fullScreenPerform.module.scss';
import { webgalStore } from '@/store/store';
import { getRandomPerformName } from '@/Core/Modules/perform/performController';
import { getBooleanArgByKey } from '@/Core/util/getSentenceArg';
import { WebGAL } from '@/Core/WebGAL';
/**
 * 播放一段视频 * @param sentence
 */
export const playVideo = (sentence: ISentence): IPerform => {
  const userDataState = webgalStore.getState().userData;
  const mainVol = userDataState.optionData.volumeMain;
  const vocalVol = mainVol * 0.01 * userDataState.optionData.vocalVolume * 0.01;
  const bgmVol = mainVol * 0.01 * userDataState.optionData.bgmVolume * 0.01;
  const performInitName: string = getRandomPerformName();

  let blockingNextFlag = getBooleanArgByKey(sentence, 'skipOff') ?? false;
  let isOver = false;
  let waitingForPlay = true;
  let releaseSource = ()=>{};
  let skipVideo = () => {};
  const restoreVolumeAndUnmount = () => {
    isOver = true;
    const video = document.getElementById('playVideoElement') as HTMLVideoElement | null;
    if(video) { cancelMediaRecovery(video); video.pause(); }
    releaseSource();
    WebGAL.events.fullscreenDbClick.off(skipVideo);
    /**
     * 恢复音量
     */
    const bgmElement: any = document.getElementById('currentBgm');
    if (bgmElement) {
      bgmElement.volume = bgmVol.toString();
    }
    const vocalElement: any = document.getElementById('currentVocal');
    if (vocalElement) {
      vocalElement.volume = vocalVol.toString();
    }
    // eslint-disable-next-line react/no-deprecated
    ReactDOM.render(<div />, document.getElementById('videoContainer'));
  };
  const endPerform = () => {
    if (isOver) return;
    isOver = true;
    WebGAL.gameplay.performController.unmountPerform(performInitName);
  };
  skipVideo = () => {
    endPerform();
  };
  const renderVideo = async () => {
    try {
      const resolved=await resolveVideoSource(sentence.content);
      if(isOver){resolved.release();return;}
      releaseSource=resolved.release;
      // eslint-disable-next-line react/no-deprecated
      ReactDOM.render(
        <div className={styles.videoContainer}>
          <video className={styles.fullScreen_video} id="playVideoElement" src={resolved.url} autoPlay={false} playsInline={true} />
        </div>,
        document.getElementById('videoContainer'),
        // 挂载完成后再操作视频元素，不依赖固定延时猜测 DOM 是否就绪。
        () => {
          if (isOver) return;
          let VocalControl: any = document.getElementById('playVideoElement');
          if (VocalControl !== null) {
            VocalControl.currentTime = 0;
            VocalControl.volume = bgmVol;
            /**
             * 把bgm和语音的音量设为0
             */
            const bgmElement: any = document.getElementById('currentBgm');
            if (bgmElement) {
              bgmElement.volume = '0';
            }
            const vocalElement: any = document.getElementById('currentVocal');
            if (vocalElement) {
              vocalElement.volume = '0';
            }

            VocalControl.addEventListener('error', () => { waitingForPlay=true; queueMediaRecovery(VocalControl,'视频',()=>!isOver,()=>{waitingForPlay=false;},true); });
            VocalControl.addEventListener('ended', () => endPerform());
            tryPlayMedia(VocalControl,'视频',()=>!isOver,()=>{waitingForPlay=false;});
            if (!blockingNextFlag) {
              WebGAL.events.fullscreenDbClick.on(skipVideo);
            }
          }
        },
      );
    } catch {
      if(isOver)return;
      ReactDOM.render(<div className={styles.videoContainer}><div style={{position:'absolute',top:'45%',left:'30%',color:'white',zIndex:10}}><p>视频加载失败</p><button onClick={()=>{void renderVideo();}}>重新加载</button><button onClick={endPerform}>跳过视频</button></div></div>,document.getElementById('videoContainer'));
    }
  };
  return {
    performName: performInitName,
    duration: 1000 * 60 * 60,
    isHoldOn: false,
    startFunction: () => {void renderVideo();},
    stopFunction: restoreVolumeAndUnmount,
    blockingNext: () => blockingNextFlag || waitingForPlay,
    blockingAuto: () => !isOver,
    goNextWhenOver: true,
  };
};
