import { tryPlayMedia, queueMediaRecovery, cancelMediaRecovery } from '@/Core/util/mediaRecovery';
import { ISentence } from '@/Core/controller/scene/sceneInterface';
import { logger } from '@/Core/util/logger';
import { webgalStore } from '@/store/store';
import { getNumberArgByKey, getStringArgByKey } from '@/Core/util/getSentenceArg';
import { createNonePerform, IPerform } from '@/Core/Modules/perform/performInterface';
import { WebGAL } from '@/Core/WebGAL';
import { WEBGAL_NONE } from '@/Core/constants';

/**
 * 播放一段效果音
 * @param sentence 语句
 */
export const playEffect = (sentence: ISentence): IPerform => {
  logger.debug('play SE');
  // 如果有ID，这里被覆写，一般用于循环的情况
  // 有循环参数且有 ID，就循环
  let performInitName = 'effect-sound';
  // 清除先前的效果音
  WebGAL.gameplay.performController.unmountPerform(performInitName, true);
  let url = sentence.content;
  let isLoop = false;
  // 清除带 id 的效果音
  const id = getStringArgByKey(sentence, 'id') ?? '';
  if (id) {
    performInitName = `effect-sound-${id}`;
    WebGAL.gameplay.performController.unmountPerform(performInitName, true);
    isLoop = true;
  }
  let isOver = false;
  let seElement: HTMLAudioElement | null = null;
  let fadeInTimer: ReturnType<typeof setInterval> | undefined;
  let unsubscribe: (()=>void) | undefined;
  let visibility: (()=>void) | undefined;
  if (!url || url === WEBGAL_NONE) {
    return createNonePerform({ blockingAuto: false });
  }
  return {
    performName: performInitName,
    duration: 1000 * 60 * 60,
    isHoldOn: isLoop,
    skipNextCollect: true,
    startFunction: () => {
      let volume = getNumberArgByKey(sentence, 'volume') ?? 100; // 获取音量比
      volume = Math.max(0, Math.min(volume, 100)); // 限制音量在 0-100 之间
      seElement = document.createElement('audio');
      seElement.src = url;
      if (isLoop) {
        seElement.loop = true;
      }
      const userDataState = webgalStore.getState().userData;
      const mainVol = userDataState.optionData.volumeMain;
      const seVol = mainVol * 0.01 * (userDataState.optionData?.seVolume ?? 100) * 0.01 * volume * 0.01;
      seElement.volume = isLoop ? 0 : seVol;
      if (isLoop) {
        const audio = seElement;
        let gain = 0;
        const refresh = () => {
          const opts = webgalStore.getState().userData.optionData;
          audio.volume = Math.max(0, Math.min(1, opts.volumeMain/100 * (opts.seVolume ?? 100)/100 * volume/100 * gain));
        };
        unsubscribe = webgalStore.subscribe(refresh);
        const began = Date.now();
        fadeInTimer = setInterval(()=>{gain=Math.min(1,(Date.now()-began)/1000);refresh();if(gain===1)clearInterval(fadeInTimer);},40);
        visibility=()=>{if(document.hidden)audio.pause();else tryPlayMedia(audio,'环境声',()=>seElement===audio);};
        document.addEventListener('visibilitychange',visibility);
      }
      seElement.currentTime = 0;
      const endFunc = () => {
        isOver = true;
        WebGAL.gameplay.performController.unmountPerform(performInitName);
      };
      seElement.onended = endFunc;
      seElement.addEventListener('error', () => {
        logger.error(`播放效果音失败: ${url}`);
        if(seElement)queueMediaRecovery(seElement,'音效',()=>seElement!==null,undefined,true);
      });
      const activeAudio = seElement;
      tryPlayMedia(activeAudio,isLoop?'环境声':'音效',()=>seElement===activeAudio);
    },
    blockingAuto(): boolean {
      if (isLoop) return false;
      return !isOver;
    },
    blockingNext(): boolean {
      return false;
    },
    stopFunction(): void {
      if (!seElement) return;
      const audio=seElement; seElement=null; cancelMediaRecovery(audio);
      audio.onended=null;
      clearInterval(fadeInTimer);unsubscribe?.();
      if(visibility)document.removeEventListener('visibilitychange',visibility);
      if(isLoop && !document.hidden && !audio.paused){
        const initial=audio.volume, began=Date.now();
        const timer=setInterval(()=>{const remaining=Math.max(0,1-(Date.now()-began)/650);audio.volume=initial*remaining;if(!remaining){clearInterval(timer);audio.pause();audio.remove();}},40);
      }else{audio.pause();audio.remove();}
    },
  };
};
