/** Kotonoha: block chapter entry until its explicit asset manifest is ready. */
const ready = new Set<string>();
const pending = new Map<string, Promise<void>>();
let manifest: Promise<Record<string, string[]>> | undefined;
function overlay(chapter: string) {
  const el = document.createElement('div');
  el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true');
  el.style.cssText='position:fixed;inset:0;z-index:2147483647;background:#10131bf5;color:#fff;display:grid;place-content:center;text-align:center;font:18px sans-serif;gap:18px;padding:24px';
  const title=document.createElement('div');title.textContent=`正在加载 Chapter ${chapter}`;
  const progress=document.createElement('progress');progress.max=1;progress.value=0;progress.style.cssText='width:min(70vw,440px);height:12px';
  const status=document.createElement('div');status.setAttribute('aria-live','polite');
  el.append(title,progress,status);document.body.append(el);
  el.addEventListener('click',e=>e.stopPropagation());
  const blockKeys=(e: KeyboardEvent)=>{if(e.key!=='Tab'){e.preventDefault();e.stopImmediatePropagation();}};
  window.addEventListener('keydown',blockKeys,true);
  const remove=el.remove.bind(el);el.remove=()=>{window.removeEventListener('keydown',blockKeys,true);remove();};
  return {el,progress,status};
}
export function preloadChapter(sceneUrl: string): Promise<void> {
  const match=sceneUrl.match(/chapter(1-[1-7])-(?:zh|ja)/);
  if(!match)return Promise.resolve();
  const chapter=match[1];
  if(ready.has(chapter))return Promise.resolve();
  const existing=pending.get(chapter);if(existing)return existing;
  const job=(async()=>{
    const ui=overlay(chapter);
    if ('serviceWorker' in navigator) {
      try {
        await navigator.serviceWorker.register('./chapter-cache.js');
        await navigator.serviceWorker.ready;
        if (!navigator.serviceWorker.controller) await Promise.race([
          new Promise<void>(resolve=>navigator.serviceWorker.addEventListener('controllerchange',()=>resolve(),{once:true})),
          new Promise<void>(resolve=>setTimeout(resolve,3000))
        ]);
      } catch { /* HTTP cache remains available if service workers are unsupported. */ }
    }
    let completed=0;
    const loaded=new Set<string>();
    for(;;) {
      try {
        if(!manifest)manifest=fetch('./game/chapter-assets.json',{cache:'no-cache'}).then(r=>{if(!r.ok)throw Error('清单加载失败');return r.json();}).catch(e=>{manifest=undefined;throw e;});
        const index=await manifest;
        const files=index[chapter];if(!files?.length)throw Error('本章资源清单缺失');
        const queue=files.filter(f=>!loaded.has(f));
        ui.progress.max=files.length;ui.progress.value=completed;
        const outcomes=await Promise.allSettled(Array.from({length:3},async()=>{
          while(queue.length){
            const file=queue.shift()!;
            const abort=new AbortController();const timer=setTimeout(()=>abort.abort(),90000);
            try {
              const res=await fetch(new URL(file,document.baseURI),{cache:'force-cache',signal:abort.signal});
              if(!res.ok)throw Error(`HTTP ${res.status}`);
              await res.arrayBuffer();
              loaded.add(file);completed=loaded.size;ui.progress.value=completed;
              ui.status.textContent=`${completed} / ${files.length}`;
            } finally {clearTimeout(timer);}
          }
        }));
        if(outcomes.some(x=>x.status==='rejected'))throw Error('资源加载失败');
        ready.add(chapter);ui.el.remove();return;
      } catch {
        ui.status.textContent='资源未加载完整，请检查网络后重试。';
        await new Promise<void>(resolve=>{const btn=document.createElement('button');btn.textContent='重试加载';btn.style.cssText='padding:12px 28px;cursor:pointer';btn.onclick=()=>{btn.remove();resolve();};ui.el.append(btn);});
      }
    }
  })();
  pending.set(chapter,job);job.finally(()=>pending.delete(chapter));return job;
}
