/**
 * 场景预加载
 * @param sceneList 需要预加载的场景文件列表
 */
import { sceneFetcher } from '../../controller/scene/sceneFetcher';
import { sceneParser } from '../../parser/sceneParser';
import { logger } from '@/Core/util/logger';

import { WebGAL } from '@/Core/WebGAL';

const SCENE_PREFETCH_INTERVAL_MS = 320;
const scenePrefetchQueue: Array<string> = [];
const queuedSceneUrlSet = new Set<string>();
let isScenePrefetchQueueRunning = false;

const uniqueSceneUrls = (sceneList: Array<string>) => [...new Set(sceneList.filter((sceneUrl) => !!sceneUrl))];

const runScenePrefetchQueue = () => {
  if (isScenePrefetchQueueRunning || scenePrefetchQueue.length === 0) {
    return;
  }
  isScenePrefetchQueueRunning = true;
  const sceneUrl = scenePrefetchQueue.shift() as string;
  // 为每次场景预加载保留请求间隔，避免后台预加载连续争抢当前场景的加载资源。
  setTimeout(async () => {
    if (WebGAL.sceneManager.settledScenes.has(sceneUrl)) {
      queuedSceneUrlSet.delete(sceneUrl);
      isScenePrefetchQueueRunning = false;
      runScenePrefetchQueue();
      return;
    }
    WebGAL.sceneManager.settledScenes.add(sceneUrl);
    queuedSceneUrlSet.delete(sceneUrl);
    try {
      logger.info(`现在预加载场景${sceneUrl}`);
      const rawScene = await sceneFetcher(sceneUrl);
      // 注意：这里只做深度 1。sceneParser 内部会触发 assetsPrefetcher，
      // 并只预加载该子场景前 N 行资源（由 assetsPrefetcher 的 line gate 控制）。
      sceneParser(rawScene, sceneUrl, sceneUrl);
    } catch (e) {
      logger.error(`场景预加载失败：${sceneUrl}`, e);
      WebGAL.sceneManager.settledScenes.delete(sceneUrl);
    } finally {
      isScenePrefetchQueueRunning = false;
      runScenePrefetchQueue();
    }
  }, SCENE_PREFETCH_INTERVAL_MS);
};

export const scenePrefetcher = (sceneList: Array<string>): void => {
  for (const sceneUrl of uniqueSceneUrls(sceneList)) {
    // Chapters are loaded only upon entry, never by speculative traversal.
    if (/chapter1-[1-7]-(?:zh|ja)/.test(sceneUrl)) continue;
    if (WebGAL.sceneManager.settledScenes.has(sceneUrl) || queuedSceneUrlSet.has(sceneUrl)) {
      continue;
    }
    queuedSceneUrlSet.add(sceneUrl);
    scenePrefetchQueue.push(sceneUrl);
  }
  runScenePrefetchQueue();
};
