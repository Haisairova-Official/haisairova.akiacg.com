import { webgalStore } from '@/store/store';
import { setOptionData } from '@/store/userDataReducer';
// Recover media blocked by mobile autoplay or failed network loads without silently skipping it.
type Pending = { src: string; valid: () => boolean; success?: () => void; label: string; reload: boolean };
const pending = new Map<HTMLMediaElement, Pending>();
let banner: HTMLButtonElement | null = null;
function updateBanner() {
  for (const [media, item] of pending) if (!item.valid() || media.src !== item.src) pending.delete(media);
  if (!pending.size) { banner?.remove(); banner = null; return; }
  if (!banner) {
    banner = document.createElement('button');
    banner.id = 'koto-media-recovery';
    banner.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:2147483646;background:#142332;color:white;border:1px solid #aacce0;border-radius:10px;padding:12px 18px;font:16px sans-serif;max-width:90vw;pointer-events:auto';
    banner.addEventListener('pointerdown', e => e.stopPropagation());
    banner.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); for (const [media,item] of [...pending]) {
      if (!item.valid() || media.src !== item.src) { pending.delete(media); continue; }
      if (item.reload) media.load();
      tryPlayMedia(media,item.label,item.valid,item.success);
    } updateBanner(); });
    document.body.appendChild(banner);
  }
  banner.textContent = [...pending.keys()].some(m=>m.tagName==='VIDEO') ? '视频尚未播放，点此重试（可用跳过按钮）' : '声音尚未播放，点此启用／重试';
}
export function cancelMediaRecovery(media: HTMLMediaElement) { pending.delete(media); updateBanner(); }
export function queueMediaRecovery(media: HTMLMediaElement, label: string, valid: () => boolean, success?: () => void, reload = false) {
  if (!valid()) return;
  pending.set(media,{src:media.src,valid,success,label,reload}); updateBanner();
}
export function tryPlayMedia(media: HTMLMediaElement, label: string, valid: () => boolean = ()=>true, success?: () => void) {
  const src = media.src;
  const timeout=setTimeout(()=>{if(valid()&&media.src===src)queueMediaRecovery(media,label,valid,success,true);},12000);
  if (!valid()) return;
  const failed = (error: unknown) => {
    clearTimeout(timeout);
    if (!valid() || media.src !== src) return;
    if ((error as {name?:string})?.name === 'AbortError') return;
    queueMediaRecovery(media,label,valid,success,(error as {name?:string})?.name !== 'NotAllowedError');
  };
  try { media.play().then(()=>{clearTimeout(timeout);if(valid()&&media.src===src){pending.delete(media);updateBanner();success?.();}},failed); } catch(error) { failed(error); }
}

// A deliberate user gesture on mobile, also exposes a small output test.
export function installSoundCheck() {
  if(document.getElementById('koto-sound-check')) return;
  const button=document.createElement('button');
  button.id='koto-sound-check'; button.textContent='启用声音／测试';
  button.style.cssText='position:fixed;right:10px;top:10px;z-index:2147483645;background:#142332dd;color:#fff;border:1px solid #adc6d8;border-radius:8px;padding:8px 10px;font:13px sans-serif;pointer-events:auto';
  button.addEventListener('pointerdown',e=>e.stopPropagation());
  button.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();
    const opts=webgalStore.getState().userData.optionData;
    for(const key of ['volumeMain','seVolume','bgmVolume'] as const) if(!Number.isFinite(opts[key])||opts[key]===0)webgalStore.dispatch(setOptionData({key,value:key==='bgmVolume'?50:100}));
    const sound=document.createElement('audio');sound.src='./game/vocal/sfx10_bell_r16.mp3';sound.volume=.65;
    button.textContent='正在测试声音…';
    setTimeout(()=>{if(button.textContent==='正在测试声音…')button.textContent='测试超时，点击重试（网络状态 '+sound.networkState+'）';},12000);
    sound.addEventListener('ended',()=>{button.textContent='重试声音／测试';sound.remove();});
    sound.addEventListener('error',()=>{button.textContent='测试音失败（媒体错误 '+(sound.error?.code ?? '?')+'），点此重试';cancelMediaRecovery(sound);});
    tryPlayMedia(sound,'测试音',()=>true,()=>{button.textContent='测试音播放中';});
    for(const [media,item] of [...pending]) if(item.valid()&&media.src===item.src)tryPlayMedia(media,item.label,item.valid,item.success);
    const bgm=document.getElementById('currentBgm') as HTMLAudioElement|null;
    if(bgm?.getAttribute('src'))tryPlayMedia(bgm,'背景音乐',()=>bgm.isConnected);
  });
  document.body.appendChild(button);
}
