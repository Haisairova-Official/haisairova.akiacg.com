export async function resolveVideoSource(source: string): Promise<{url:string;release:()=>void}> {
  if(!source.endsWith('ed_web_r16.mp4'))return {url:source,release:()=>{}};
  const base=new URL(source,document.baseURI);
  const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),90000);
  try {
    const manifest=await fetch(new URL('ed-r17.parts.json',base),{signal:controller.signal,cache:'force-cache'});
    if(!manifest.ok)throw Error('ED manifest '+manifest.status);
    const meta=await manifest.json() as {mime:string;size:number;sha256:string;parts:{file:string;size:number}[]};
    const buffers:ArrayBuffer[]=[];
    for(const part of meta.parts){
      const response=await fetch(new URL(part.file,base),{signal:controller.signal,cache:'force-cache'});
      if(!response.ok)throw Error('ED part '+response.status);
      const bytes=await response.arrayBuffer();if(bytes.byteLength!==part.size)throw Error('ED incomplete');buffers.push(bytes);
    }
    const blob=new Blob(buffers,{type:meta.mime});if(blob.size!==meta.size)throw Error('ED size mismatch');
    const digest=await crypto.subtle.digest('SHA-256',await blob.arrayBuffer());
    const actual=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');
    if(actual!==meta.sha256)throw Error('ED integrity mismatch');
    const url=URL.createObjectURL(blob);return {url,release:()=>URL.revokeObjectURL(url)};
  } finally {clearTimeout(timeout);}
}
