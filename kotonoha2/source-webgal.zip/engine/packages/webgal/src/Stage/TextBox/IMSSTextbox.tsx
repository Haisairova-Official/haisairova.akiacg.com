import styles from './textbox.module.scss';
import { useEffect, useRef } from 'react';
import { WebGAL } from '@/Core/WebGAL';
import { ITextboxProps } from './types';
import useApplyStyle from '@/hooks/useApplyStyle';
import { css } from '@emotion/css';
import { textSize } from '@/store/userDataInterface';
import { useSelector } from 'react-redux';
import { RootState } from '@/store/store';

export default function IMSSTextbox(props: ITextboxProps) {
  const {
    textArray,
    textDelay,
    concatPrefixNodeCount,
    currentDialogKey,
    isRead,
    isText,
    isPreview = false,
    isSafari,
    isFirefox: boolean,
    fontSize,
    miniAvatar,
    isHasName,
    showName,
    font,
    textDuration,
    textRevealEnd,
    isUseStroke,
    textboxOpacity,
    textSizeState,
  } = props;

  const applyStyle = useApplyStyle('textbox');
  const readTextClassName = isRead ? ` ${applyStyle('readText', styles.readText)}` : '';
  const readTextInnerClassName = isRead ? ` ${applyStyle('readTextInner', styles.readTextInner)}` : '';
  const textboxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isPreview) return;
    function settleText() {
      // 只结算本实例的文字，避免剧情演出打断设置页的预览。
      textboxRef.current?.querySelectorAll('.Textelement_start').forEach((e) => {
        e.className = applyStyle('TextBox_textElement_Settled', styles.TextBox_textElement_Settled);
      });
    }

    WebGAL.events.textSettle.on(settleText);
    return () => {
      WebGAL.events.textSettle.off(settleText);
    };
  }, [isPreview]);
  let allTextIndex = 0;
  const nameElementList = showName.map((line, index) => {
    const textline = line.map((en, index) => {
      const e = en.reactNode;
      let style = '';
      let tips = '';
      let style_alltext = '';
      let isEnhanced = false;
      if (en.enhancedValue) {
        isEnhanced = true;
        const data = en.enhancedValue;
        for (const dataElem of data) {
          const { key, value } = dataElem;
          switch (key) {
            case 'style':
              style = value;
              break;
            case 'tips':
              tips = value;
              break;
            case 'style-alltext':
              style_alltext = value;
              break;
          }
        }
      }
      const styleClassName = ' ' + css(style, { label: 'showname' });
      const styleAllText = ' ' + css(style_alltext, { label: 'showname' });
      if (isEnhanced) {
        return (
          <span key={index} style={{ position: 'relative' }}>
            <span className={styles.zhanwei + styleAllText}>
              {e}
              <span className={applyStyle('outerName', styles.outerName) + styleClassName + styleAllText}>{e}</span>
              {isUseStroke && <span className={applyStyle('innerName', styles.innerName) + styleAllText}>{e}</span>}
            </span>
          </span>
        );
      }
      return (
        <span key={index} style={{ position: 'relative' }}>
          <span className={styles.zhanwei + styleAllText}>
            {e}
            <span className={applyStyle('outerName', styles.outerName) + styleClassName + styleAllText}>{e}</span>
            {isUseStroke && <span className={applyStyle('innerName', styles.innerName) + styleAllText}>{e}</span>}
          </span>
        </span>
      );
    });
    return (
      <div
        style={{
          wordBreak: isSafari || props.isFirefox ? 'break-all' : undefined,
          display: isSafari ? 'flex' : undefined,
          flexWrap: isSafari ? 'wrap' : undefined,
        }}
        key={`text-line-${index}`}
      >
        {textline}
      </div>
    );
  });
  const textElementList = textArray.map((line, index) => {
    const textLine = line.map((en, index) => {
      const e = en.reactNode;
      let style = '';
      let tips = '';
      let style_alltext = '';
      if (en.enhancedValue) {
        const data = en.enhancedValue;
        for (const dataElem of data) {
          const { key, value } = dataElem;
          switch (key) {
            case 'style':
              style = value;
              break;
            case 'tips':
              tips = value;
              break;
            case 'style-alltext':
              style_alltext = value;
              break;
          }
        }
      }
      // if (e === '<br />') {
      //   return <br key={`br${index}`} />;
      // }
      const outerClassName = applyStyle('outer', styles.outer);
      const readTextOuterClassName = isRead ? ` ${applyStyle('readTextOuter', styles.readTextOuter)}` : '';
      const nodeIndex = allTextIndex++;
      // concat 继承的前缀直接显示；新接上的字从本句开始重新计算延迟
      const isConcatPrefix = nodeIndex < concatPrefixNodeCount;
      const delay = (isConcatPrefix ? nodeIndex : nodeIndex - concatPrefixNodeCount) * textDelay;
      // notend 末尾逐渐缩短渐显，确保推进时已经全显，stopFunction 无需特殊处理。
      const duration =
        textRevealEnd === undefined ? textDuration : Math.min(textDuration, Math.max(0, textRevealEnd - delay));
      const styleClassName = ' ' + css(style);
      const styleAllText = ' ' + css(style_alltext);
      if (isConcatPrefix) {
        return (
          <span
            // data-text={e}
            id={`${delay}`}
            className={
              applyStyle('TextBox_textElement_Settled', styles.TextBox_textElement_Settled) + readTextClassName
            }
            key={currentDialogKey + index}
            style={{ animationDelay: `${delay}ms`, animationDuration: `${textDuration}ms` }}
          >
            <span className={styles.zhanwei + styleAllText}>
              {e}
              <span data-koto-glyph="true" className={outerClassName + readTextOuterClassName + styleClassName + styleAllText}>{e}</span>
              {isUseStroke && (
                <span data-koto-stroke="true" className={applyStyle('inner', styles.inner) + readTextInnerClassName + styleAllText}>{e}</span>
              )}
            </span>
          </span>
        );
      }
      return (
        <span
          // data-text={e}
          id={`${delay}`}
          className={`${applyStyle(
            'TextBox_textElement_start',
            styles.TextBox_textElement_start,
          )}${readTextClassName} Textelement_start`}
          key={currentDialogKey + index}
          style={{ animationDelay: `${delay}ms`, animationDuration: `${duration}ms`, position: 'relative' }}
        >
          <span className={styles.zhanwei + styleAllText}>
            {e}
            <span data-koto-glyph="true" className={outerClassName + readTextOuterClassName + styleClassName + styleAllText}>{e}</span>
            {isUseStroke && (
              <span data-koto-stroke="true" className={applyStyle('inner', styles.inner) + readTextInnerClassName + styleAllText}>{e}</span>
            )}
          </span>
        </span>
      );
    });
    return (
      <div
        style={{
          wordBreak: isSafari || props.isFirefox ? 'break-all' : undefined,
          display: isSafari ? 'flex' : undefined,
          flexWrap: isSafari ? 'wrap' : undefined,
        }}
        key={`text-line-${index}`}
      >
        {textLine}
      </div>
    );
  });

  const userDataState = useSelector((state: RootState) => state.userData);
  const lineHeightValue = textSizeState === textSize.medium ? 2.2 : 2;
  const textLineHeight = userDataState.globalGameVar.Line_height;
  const finalTextLineHeight = textLineHeight ? Number(textLineHeight) : lineHeightValue;
  const lineHeightCssStr = `line-height: ${finalTextLineHeight}em`;
  const lhCss = css(lineHeightCssStr);

  return (
    <>
      {isText && (
        <div ref={textboxRef} className={styles.TextBox_Container}>
          <div
            className={
              applyStyle('TextBox_main', styles.TextBox_main) +
              ' ' +
              applyStyle('TextBox_Background', styles.TextBox_Background) +
              ' ' +
              (miniAvatar === ''
                ? applyStyle('TextBox_main_miniavatarOff', styles.TextBox_main_miniavatarOff)
                : undefined)
            }
            style={{
              opacity: `${textboxOpacity / 100}`,
            }}
          />
          <div
            id="textBoxMain"
            data-koto-read={isRead ? "true" : "false"}
            className={
              applyStyle('TextBox_main', styles.TextBox_main) +
              ' ' +
              (miniAvatar === ''
                ? applyStyle('TextBox_main_miniavatarOff', styles.TextBox_main_miniavatarOff)
                : undefined)
            }
            style={{
              fontFamily: font,
            }}
          >
            <div id="miniAvatar" className={applyStyle('miniAvatarContainer', styles.miniAvatarContainer)}>
              {miniAvatar !== '' && (
                <img className={applyStyle('miniAvatarImg', styles.miniAvatarImg)} alt="miniAvatar" src={miniAvatar} />
              )}
            </div>
            {isHasName && (
              <>
                <div
                  className={
                    applyStyle('TextBox_showName', styles.TextBox_showName) +
                    ' ' +
                    applyStyle('TextBox_ShowName_Background', styles.TextBox_ShowName_Background)
                  }
                  style={{
                    opacity: `${textboxOpacity / 100}`,
                    fontSize: '200%',
                  }}
                >
                  <span style={{ opacity: 0 }}>{nameElementList}</span>
                </div>
                <div
                  className={applyStyle('TextBox_showName', styles.TextBox_showName)}
                  style={{
                    fontSize: '200%',
                  }}
                >
                  {nameElementList}
                </div>
              </>
            )}
            <div
              data-koto-body="true"
              className={`${lhCss} ${applyStyle('text', styles.text)}`}
              style={{
                fontSize,
                flexFlow: 'column',
                overflow: 'hidden',
                paddingLeft: '0.1em',
                // lineHeight: textSizeState === textSize.medium ? '2.2em' : '2em', // 不加的话上半拼音可能会被截断，同时保持排版整齐
              }}
            >
              {textElementList}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
